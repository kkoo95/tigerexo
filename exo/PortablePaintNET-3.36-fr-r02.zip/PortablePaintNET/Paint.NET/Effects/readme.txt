pyrochild plugins
July 4, 2008

To install plugins:
 copy "pyrochild.effects.common.dll" and any desired plugin to the Paint.NET\Effects folder.

To install ScriptLab and ScriptLab Batch Processor
 run ScriptLab Setup.exe by double-clicking its icon. You may requre administrator priveleges.